import React from 'react'

export default function Index() {
  return (
    <div>home</div>
  )
}
